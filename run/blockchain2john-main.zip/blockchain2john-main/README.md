# blockchain2john
Blockchain2john.py is a python program to extract blockchain.com wallet.aes.json wallet to hash. its updated blockchain2john.py to extract hash of Wallet V4.

command : python blockchain2john.py --json wallet.aes.json 

